# CallAdmin - Web
Ugly code :>

## Credits
We use these open-source third-party libraries.

 * [TS3 PHP Framework](http://www.planetteamspeak.com/)
 * [FeedWriter](https://github.com/mibe/FeedWriter)